﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace Practice3
{
    public partial class RequestsForm : Form
    {
        public RequestsForm()
        {
            InitializeComponent();
        }

        private void RequestsForm_Load(object sender, EventArgs e)
        {
            if (File.Exists("practice3db.db"))
            {

                using (var conn = new SqliteConnection("Data Source=practice3db.db"))
                {
                    conn.Open();

                    using (var cmd = new SqliteCommand("SELECT ClientInfo FROM Requests", conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cmbClient.Items.Add(reader.GetString(0));
                        }

                    }

                    using (var cmd = new SqliteCommand("SELECT NameOfDevice FROM Devices", conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cmbDevice.Items.Add(reader.GetString(0));
                        }

                    }

                    using (var cmd = new SqliteCommand("SELECT NameOfStatus FROM Statuses", conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cmbStatus.Items.Add(reader.GetString(0));
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Файл базы данных не найден");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }
    }
}
