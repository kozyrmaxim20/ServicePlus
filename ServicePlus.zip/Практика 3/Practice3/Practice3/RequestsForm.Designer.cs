﻿namespace Practice3
{
    partial class RequestsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            cmbClient = new ComboBox();
            cmbDevice = new ComboBox();
            cmbStatus = new ComboBox();
            txtProblem = new TextBox();
            btnSave = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.White;
            label1.Location = new Point(48, 36);
            label1.Name = "label1";
            label1.Size = new Size(70, 19);
            label1.TabIndex = 0;
            label1.Text = "Клиент:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.White;
            label2.Location = new Point(48, 83);
            label2.Name = "label2";
            label2.Size = new Size(101, 19);
            label2.TabIndex = 1;
            label2.Text = "Устройство:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.White;
            label3.Location = new Point(48, 138);
            label3.Name = "label3";
            label3.Size = new Size(66, 19);
            label3.TabIndex = 2;
            label3.Text = "Статус:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.White;
            label4.Location = new Point(48, 189);
            label4.Name = "label4";
            label4.Size = new Size(93, 19);
            label4.TabIndex = 3;
            label4.Text = "Проблема:";
            // 
            // cmbClient
            // 
            cmbClient.BackColor = Color.Salmon;
            cmbClient.FormattingEnabled = true;
            cmbClient.Location = new Point(124, 33);
            cmbClient.Name = "cmbClient";
            cmbClient.Size = new Size(121, 26);
            cmbClient.TabIndex = 4;
            // 
            // cmbDevice
            // 
            cmbDevice.BackColor = Color.Salmon;
            cmbDevice.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDevice.FormattingEnabled = true;
            cmbDevice.Location = new Point(155, 80);
            cmbDevice.Name = "cmbDevice";
            cmbDevice.Size = new Size(121, 26);
            cmbDevice.TabIndex = 5;
            // 
            // cmbStatus
            // 
            cmbStatus.BackColor = Color.Salmon;
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(120, 135);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(121, 26);
            cmbStatus.TabIndex = 6;
            // 
            // txtProblem
            // 
            txtProblem.BackColor = Color.Salmon;
            txtProblem.Location = new Point(141, 186);
            txtProblem.Multiline = true;
            txtProblem.Name = "txtProblem";
            txtProblem.Size = new Size(100, 31);
            txtProblem.TabIndex = 7;
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.IndianRed;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Location = new Point(429, 471);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(139, 36);
            btnSave.TabIndex = 8;
            btnSave.Text = "Сохранить";
            btnSave.UseVisualStyleBackColor = false;
            // 
            // RequestsForm
            // 
            AutoScaleDimensions = new SizeF(9F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCoral;
            ClientSize = new Size(1028, 540);
            Controls.Add(btnSave);
            Controls.Add(txtProblem);
            Controls.Add(cmbStatus);
            Controls.Add(cmbDevice);
            Controls.Add(cmbClient);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Arial Black", 10F);
            Name = "RequestsForm";
            Text = "Новая заявка";
            Load += RequestsForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox cmbClient;
        private ComboBox cmbDevice;
        private ComboBox cmbStatus;
        private TextBox txtProblem;
        private Button btnSave;
    }
}