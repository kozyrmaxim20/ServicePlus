﻿namespace Practice3
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            заявкиToolStripMenuItem = new ToolStripMenuItem();
            клиентыToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.IndianRed;
            menuStrip1.Items.AddRange(new ToolStripItem[] { заявкиToolStripMenuItem, клиентыToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1028, 27);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // заявкиToolStripMenuItem
            // 
            заявкиToolStripMenuItem.Font = new Font("Arial Black", 10F);
            заявкиToolStripMenuItem.ForeColor = Color.White;
            заявкиToolStripMenuItem.Name = "заявкиToolStripMenuItem";
            заявкиToolStripMenuItem.Size = new Size(77, 23);
            заявкиToolStripMenuItem.Text = "Заявки";
            заявкиToolStripMenuItem.Click += заявкиToolStripMenuItem_Click;
            // 
            // клиентыToolStripMenuItem
            // 
            клиентыToolStripMenuItem.Font = new Font("Arial Black", 10F);
            клиентыToolStripMenuItem.ForeColor = Color.White;
            клиентыToolStripMenuItem.Name = "клиентыToolStripMenuItem";
            клиентыToolStripMenuItem.Size = new Size(90, 23);
            клиентыToolStripMenuItem.Text = "Клиенты";
            клиентыToolStripMenuItem.Click += клиентыToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.Dock = DockStyle.Fill;
            label1.ForeColor = Color.White;
            label1.Location = new Point(0, 27);
            label1.Name = "label1";
            label1.Size = new Size(1028, 513);
            label1.TabIndex = 1;
            label1.Text = "Добро пожаловать! Выберите раздел в меню сверху";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(9F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCoral;
            ClientSize = new Size(1028, 540);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            Font = new Font("Arial Black", 10F);
            MainMenuStrip = menuStrip1;
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Главная — СервисПлюс";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem заявкиToolStripMenuItem;
        private ToolStripMenuItem клиентыToolStripMenuItem;
        private Label label1;
    }
}