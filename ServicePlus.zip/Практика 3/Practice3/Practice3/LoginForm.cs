using Microsoft.Data.Sqlite;

namespace Practice3
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            using (var conn = new SqliteConnection("Data Source=practice3db.db"))
            {
                conn.Open();

                string sql = "SELECT RoleID FROM Users WHERE LoginOfUser = @l AND PasswordOfUser = @p ";

                using (var cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@l", txtLogin.Text);
                    cmd.Parameters.AddWithValue("@p", txtPassword.Text);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int roleid = reader.GetInt32(0);
                            if (roleid == 1)
                            {
                                MainForm main = new MainForm();
                                main.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("функционал в разработке");
                            }
                        }
                        else
                        {
                            MessageBox.Show("неверный логин или пароль");
                        }
                    }
                }
            }
        }
     

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
