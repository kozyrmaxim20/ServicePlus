﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Practice3
{
    public partial class ClientsForm : Form
    {
        public ClientsForm()
        {
            InitializeComponent();
        }

        private void ClientsForm_Load(object sender, EventArgs e)
        {
            var dt = new DataTable();

            using (var conn = new SqliteConnection("Data Source=practice3db.db"))
            {
                conn.Open();

                using (var cmd = new SqliteCommand("SELECT ClientInfo FROM Requests", conn))

                using (var reader = cmd.ExecuteReader())
                {
                    dt.Load(reader);
                }
            }
            dgvClients.DataSource = dt;
        }
    }
}
